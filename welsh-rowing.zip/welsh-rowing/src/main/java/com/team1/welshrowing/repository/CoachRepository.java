package com.team1.welshrowing.repository;

public interface CoachRepository {



}
