package com.team1.welshrowing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WelshRowingApplicationTests {

    @Test
    void contextLoads() {
    }

}
